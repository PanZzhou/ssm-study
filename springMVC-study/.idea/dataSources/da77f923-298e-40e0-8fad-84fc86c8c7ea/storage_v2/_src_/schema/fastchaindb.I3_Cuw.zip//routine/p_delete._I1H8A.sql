create
    definer = root@`%` procedure p_delete(IN i_id varchar(50), IN i_tablename varchar(50), IN i_ip varchar(50),
                                          IN i_userid varchar(50), IN i_des varchar(500), OUT o_msg varchar(200))
begin








declare my_sql varchar(500); 

DECLARE t_error INTEGER DEFAULT 0;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
START TRANSACTION;





if (i_tablename = 'sys_station1') THEN

  select count(*) into @cnt from sys_process_flow where station_id=i_id;
  if (@cnt=0) then
		delete from sys_station where id=i_id;
  else 
		set t_error=3;
  end if;


elseif (i_tablename = 'sys_plc') THEN

	delete from sys_plc where id=i_id;
	delete from sys_unit_plc where plc_id=i_id;


elseif (i_tablename = 'sys_device') THEN

	delete from sys_device where id=i_id;
	delete from sys_unit_device where device_id=i_id;


elseif (i_tablename = 'lab_quota_data') THEN

	delete from lab_quota_data where batch_id=i_id;


elseif (i_tablename = 'lab_task') THEN
  select count(*) into @cnt from lab_sample where task_id=i_id;
  if (@cnt=0) then
		delete from lab_task where id=i_id;
		delete from lab_process_step where task_id=i_id;
  else 
		set t_error=3;
  end if;


else

 set my_sql=concat('delete from ',i_tablename,' where id=''',i_id,''''); 
 set @ms=my_sql; 
 PREPARE s1 from @ms; 
 EXECUTE s1; 
 deallocate prepare s1; 

end if;








IF t_error = 1 THEN
    ROLLBACK;
ELSE
    COMMIT;
END IF;

set o_msg=t_error;
 
end;

