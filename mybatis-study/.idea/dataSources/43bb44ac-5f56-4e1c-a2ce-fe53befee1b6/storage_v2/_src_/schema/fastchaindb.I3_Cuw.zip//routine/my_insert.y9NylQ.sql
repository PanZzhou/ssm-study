create
    definer = root@localhost procedure my_insert()
BEGIN
   DECLARE n int DEFAULT 1;
        loopname:LOOP
            INSERT INTO sys_login_record(user_id,os_name,create_time)VALUES(2,'lilis',NOW());
            SET n=n+1;
        IF n=1000 THEN
            LEAVE loopname;
        END IF;
        END LOOP loopname;
END;

