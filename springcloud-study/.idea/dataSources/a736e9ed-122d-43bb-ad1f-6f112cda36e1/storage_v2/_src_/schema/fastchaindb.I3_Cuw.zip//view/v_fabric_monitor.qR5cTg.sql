create definer = root@`%` view v_fabric_monitor as
select `a`.`id`              AS `id`,
       `a`.`channel_name`    AS `channel_name`,
       `a`.`org_name`        AS `org_name`,
       `b`.`order_name`      AS `order_name`,
       `b`.`order_ip`        AS `order_ip`,
       `c`.`chain_code_name` AS `chain_code_name`,
       `c`.`peer_name`       AS `peer_name`,
       `c`.`peer_ip`         AS `peer_ip`
from ((`fastchaindb`.`fabric_monitor` `a` left join `fastchaindb`.`fabric_monitor_order` `b` on ((`a`.`id` = `b`.`fabric_monitor_id`)))
         left join `fastchaindb`.`fabric_monitor_peer` `c` on ((`a`.`id` = `c`.`fabric_monitor_id`)));

